<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <div class="profile">
            <img src="<?php echo e(asset('image/profile_picture/')); ?>/<?php echo $__env->yieldContent('profile_image'); ?>" style="width:150px; height:150px;" alt="Profile" class="profile_pic">
            <br>
            <br>
            <h7>Name: <b><?php echo $__env->yieldContent('user_name'); ?></b></h7>
            <h7>Phone:<b><?php echo $__env->yieldContent('phone'); ?></b></h7>
            <br>
            <br>
        </div>

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed1'); ?>" href="<?php echo $__env->yieldContent('link1'); ?>">
                <i class="<?php echo $__env->yieldContent('icon1'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name1'); ?></span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed2'); ?>" href="<?php echo $__env->yieldContent('link2'); ?>">
                <i class="<?php echo $__env->yieldContent('icon2'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name2'); ?></span>
            </a>
        </li><!-- End Profile Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed3'); ?>" href="<?php echo $__env->yieldContent('link3'); ?>">
                <i class="<?php echo $__env->yieldContent('icon3'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name3'); ?></span>
            </a>
        </li><!-- End F.A.Q Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed4'); ?>" href="<?php echo $__env->yieldContent('link4'); ?>">
                <i class="<?php echo $__env->yieldContent('icon4'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name4'); ?></span>
            </a>
        </li><!-- End Contact Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed5'); ?>" href="<?php echo $__env->yieldContent('link5'); ?>">
                <i class="<?php echo $__env->yieldContent('icon5'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name5'); ?></span>
            </a>
        </li><!-- End Register Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed6'); ?>" href="<?php echo $__env->yieldContent('link6'); ?>">
                <i class="<?php echo $__env->yieldContent('icon6'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name6'); ?></span>
            </a>
        </li><!-- End Login Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed7'); ?>" href="<?php echo $__env->yieldContent('link7'); ?>">
                <i class="<?php echo $__env->yieldContent('icon7'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name7'); ?></span>
            </a>
        </li><!-- End Error 404 Page Nav -->

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed8'); ?>" href="<?php echo $__env->yieldContent('link8'); ?>">
                <i class="<?php echo $__env->yieldContent('icon8'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name8'); ?></span>
            </a>
        </li><!-- End Blank Page Nav -->


        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('collapsed9'); ?>" href="<?php echo $__env->yieldContent('link9'); ?>">
                <i class="<?php echo $__env->yieldContent('icon9'); ?>"></i>
                <span><?php echo $__env->yieldContent('sidebar_name9'); ?></span>
            </a>
        </li><!-- End Blank Page Nav -->

    </ul>

</aside><!-- End Sidebar-->
<?php /**PATH C:\xampp\htdocs\money_saving_managment\resources\views/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>