<?php echo $__env->make('dashboard.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1><?php echo $__env->yieldContent('page_title'); ?></h1>
    </div><!-- End Page Title -->
    <section class="section dashboard">
<?php echo $__env->yieldContent('content'); ?>
</main>


<?php echo $__env->make('dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\money_saving_managment\resources\views/dashboard/layouts/usermaster.blade.php ENDPATH**/ ?>