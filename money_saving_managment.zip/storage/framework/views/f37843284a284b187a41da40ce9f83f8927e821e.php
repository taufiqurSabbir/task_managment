

<?php $__env->startSection('user_name',$user_data->name); ?>
<?php $__env->startSection('phone',$user_data->phone); ?>
<?php $__env->startSection('profile_image',$user_data->profile_picture); ?>

<?php if($user_data->user_status =='Approved'): ?>:

<?php $__env->startSection('collapsed1',''); ?>;
<?php $__env->startSection('sidebar_name1','Dashboard'); ?>
<?php $__env->startSection('link1',route('admin.dashboard')); ?>
<?php $__env->startSection('icon1','bi bi-grid'); ?>

<?php $__env->startSection('page_title','Dashboard'); ?>

<?php $__env->startSection('collapsed2','collapsed'); ?>;
<?php $__env->startSection('sidebar_name2','All Users'); ?>
<?php $__env->startSection('link2',route('all.user')); ?>
<?php $__env->startSection('icon2','bi bi-person-check'); ?>


<?php $__env->startSection('collapsed3','collapsed'); ?>;
<?php $__env->startSection('sidebar_name3','Transaction'); ?>
<?php $__env->startSection('link3',route('transaction')); ?>
<?php $__env->startSection('icon3','bi bi-cash-coin'); ?>

<?php $__env->startSection('collapsed4','collapsed'); ?>;
<?php $__env->startSection('sidebar_name4','Loan'); ?>
<?php $__env->startSection('link4',route('loan')); ?>
<?php $__env->startSection('icon4','bi bi-coin'); ?>



<?php $__env->startSection('collapsed5','collapsed'); ?>;
<?php $__env->startSection('sidebar_name5','Notice'); ?>
<?php $__env->startSection('link5',route('notice')); ?>
<?php $__env->startSection('icon5','bi bi-bell'); ?>

<?php $__env->startSection('collapsed6','collapsed'); ?>;
<?php $__env->startSection('sidebar_name6','Asset'); ?>
<?php $__env->startSection('link6',route('asset')); ?>
<?php $__env->startSection('icon6','bi bi-plus-circle'); ?>

<?php $__env->startSection('collapsed7','collapsed'); ?>;
<?php $__env->startSection('sidebar_name7','Expense'); ?>
<?php $__env->startSection('link7',route('expense')); ?>
<?php $__env->startSection('icon7','bi bi-dash-circle'); ?>

<?php $__env->startSection('collapsed8','collapsed'); ?>;
<?php $__env->startSection('sidebar_name8','Member Cancel Request'); ?>
<?php $__env->startSection('link8',route('member_cancel')); ?>
<?php $__env->startSection('icon8','bi bi-person-dash'); ?>

<?php $__env->startSection('collapsed9','collapsed'); ?>;
<?php $__env->startSection('sidebar_name9','Logout'); ?>
<?php $__env->startSection('link9',route('logout')); ?>
<?php $__env->startSection('icon9','bi bi-box-arrow-left'); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
            <div class="row">


                <!-- Sales Card -->
                <div class="col-xxl-4 col-md-6">
                    <div class="card info-card sales-card">


                        <div class="card-body">
                            <h5 class="card-title">Total Collected <span></span></h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-cash-coin"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($paid); ?>৳</h6>

                                </div>
                            </div>
                        </div>

                    </div>
                </div><!-- End Sales Card -->

                    <!-- Your Total -->
                    <div class="col-xxl-4 col-md-6">
                        <div class="card info-card revenue-card">


                            <div class="card-body">
                                <h5 class="card-title">Your Total Saving</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-cash-stack"></i>
                                    </div>
                                    <div class="ps-3">

                                        <h6><?php echo e($user_paid); ?>৳</h6>
                                        <span><p>Adjest amount <b style="color:#b01602"><?php echo e($adjest_amount); ?>৳</b></p></span>


                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Your Total -->


                    <div class="col-xxl-4 col-md-6">
                        <div class="card info-card due">


                            <div class="card-body">
                                <h5 class="card-title">Your Amount Due</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-question-octagon"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($user_due); ?>৳</h6>


                                    </div>
                                </div>
                            </div>

                        </div>
                    </div><!-- End Revenue Card -->

                <!-- Revenue Card -->
                <div class="col-xxl-4 col-md-6">
                    <div class="card info-card revenue-card">


                        <div class="card-body">
                            <h5 class="card-title">Total User</h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-person"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($total_user); ?></h6>


                                </div>
                            </div>
                        </div>

                    </div>
                </div><!-- End Revenue Card -->


                <div class="col-xxl-4 col-md-6">
                    <div class="card info-card due">


                        <div class="card-body">
                            <h5 class="card-title">Amount Due</h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-question-octagon"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($due); ?>৳</h6>


                                </div>
                            </div>
                        </div>

                    </div>
                </div><!-- End Revenue Card -->

                <!-- Customers Card -->
                <div class="col-xxl-4 col-xl-12">

                    <div class="card info-card asset">


                        <div class="card-body">
                            <h5 class="card-title">Asset</h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-shield-fill-plus"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($asset); ?></h6>


                                </div>
                            </div>

                        </div>
                    </div>

                </div><!-- End Customers Card -->

                <div class="col-xxl-4 col-xl-12">

                    <div class="card info-card expense">


                        <div class="card-body">
                            <h5 class="card-title">Expense</h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-patch-minus-fill"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($total_expense); ?></h6>


                                </div>
                            </div>

                        </div>
                    </div>

                </div><!-- End Customers Card -->

                    <div class="col-xxl-4 col-xl-12">

                        <div class="card info-card loan">


                            <div class="card-body">
                                <h5 class="card-title">Your Loan Request</h5>

                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-bank"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?php echo e($user_load_request); ?></h6>


                                    </div>
                                </div>

                            </div>
                        </div>

                    </div><!-- End Customers Card -->

                <div class="col-xxl-4 col-xl-12">

                    <div class="card info-card loan">


                        <div class="card-body">
                            <h5 class="card-title">Loan Request</h5>

                            <div class="d-flex align-items-center">
                                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                    <i class="bi bi-bank"></i>
                                </div>
                                <div class="ps-3">
                                    <h6><?php echo e($loan_req); ?></h6>


                                </div>
                            </div>

                        </div>
                    </div>

                </div><!-- End Customers Card -->




                <!-- Reports -->
                <div class="col-12">
                    <div class="card">

                        <div class="card-body">
                            <h5 class="card-title">Last Transaction</h5>

                            <!-- Line Chart -->
                            <div id="reportsChart" class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">phone</th>
                                        <th scope="col">amount</th>
                                        <th scope="col">Month</th>
                                        <th scope="col">Purpose</th>
                                        <th scope="col">status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transationn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $user_name = \App\Models\User::where('id',$transations->user_id)->first();
                                        $month_name = App\Models\Months::where('id',$transations->month_id)->first();
                                        ?>
                                    <tr>
                                        <th scope="row"><?php echo e($user_name->name); ?></th>
                                        <td><?php echo e($user_name->phone); ?></td>
                                        <td><?php echo e($transations->amount); ?></td>
                                        <td><?php echo e($month_name->months); ?></td>
                                        <td><?php echo e($transations->type); ?></td>
                                        <td>
                                            <?php if( $transations->status =='Due'): ?>
                                                <span class="badge bg-warning">Due</span>
                                            <?php elseif($transations->status =='paid'): ?>
                                                <span class="badge bg-success">Paid</span>
                                            <?php elseif($transations->status =='rejected'): ?>
                                                <span class="badge bg-danger">Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>



                        </div>

                    </div>
                </div><!-- End Reports -->

                <!-- Recent Sales -->
                <div class="col-12">
                    <div class="card">

                        <div class="card-body">
                            <h5 class="card-title">latest Amount Due</h5>

                            <!-- Line Chart -->

                            <div id="reportsChart" class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">phone</th>
                                        <th scope="col">amount</th>
                                        <th scope="col">Month</th>
                                        <th scope="col">Purpose</th>
                                        <th scope="col">status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $last_due; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $user_name = \App\Models\User::where('id',$due->user_id)->first();
                                            $month_name = App\Models\Months::where('id',$due->month_id)->first();
                                        ?>

                                    <tr>
                                        <th scope="row"><?php echo e($user_name->name); ?></th>
                                        <td><?php echo e($user_name->phone); ?></td>
                                        <td><?php echo e($due->amount); ?></td>
                                        <td><?php echo e($month_name->months); ?></td>
                                        <td><?php echo e($due->type); ?></td>
                                        <td>
                                            <?php if( $due->status =='Due'): ?>
                                                <span class="badge bg-warning">Due</span>
                                            <?php elseif($due->status =='paid'): ?>
                                                <span class="badge bg-success">Paid</span>
                                            <?php elseif($due->status =='rejected'): ?>
                                                <span class="badge bg-danger">Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>



                        </div>

                    </div>
                </div><!-- End Reports --><!-- End Recent Sales -->

                <!-- Top Selling -->


            </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

            <div class="card">
            <div class="card-body pb-0">
                <h5 class="card-title">Notice </h5>


                <div class="news">
                    <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $push_date = Illuminate\Support\Carbon::parse($notices->created_at);
                            $notice_user = \App\Models\User::where('id',$notices->user_id)->first();
                        ?>
                    <div class="post-item clearfix">
                        <h4><a href="<?php echo e(route('single.notice',$notices->id)); ?>"><?php echo e($notices->title); ?></a></h4>
                        <div class="col-sm">
                            <span>Notice By: <b><?php echo e($notice_user->name); ?></b> </span>

                            <span>Publish at: <b><?php echo e($push_date->isoFormat('Do MMM YY')); ?></b> </span>
                        </div>
                    </div>

                        <hr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- End sidebar recent posts-->

            </div>
        </div><!-- End News & Updates -->


            <!-- Recent Activity -->


            <!-- News & Updates Traffic -->

        </div><!-- End Right side columns -->

    </div>

<?php $__env->stopSection(); ?>
<?php elseif($user_data->user_status =='pending'): ?>
<?php $__env->startSection('content'); ?>

    <div class="row">


        <!-- Left side columns -->
        <div class="col-lg-8">
            <div class="row">

                <h4 style="text-align:center">Your Account is <b style="color:darkred">pending</b> </h4>
                <h5 style="text-align:center">We are checking your Information. <br> We'll inform you soon</h5>

                <img src="<?php echo e(asset('image/frontend/98723-search-users.gif')); ?>" alt="">



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php elseif($user_data->user_status =='Rejected'): ?>
<?php $__env->startSection('content'); ?>

    <div class="row">


        <!-- Left side columns -->
        <div class="col-lg-8">
            <div class="row">
                <h4 style="text-align:center">Your Account is <b style="color:darkred">Rejected</b> </h4>
                <h5 style="text-align:center">We are sorry to inform. <br> You unable to became our member</h5>

                <img src="<?php echo e(asset('image/frontend/80164-reject-document-files.gif')); ?>" style="height:50%; width:70%; margin: 0 auto" alt="">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php endif; ?>

<?php echo $__env->make('dashboard.layouts.usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\money_saving_managment\resources\views/dashboard/admin/dashboard.blade.php ENDPATH**/ ?>