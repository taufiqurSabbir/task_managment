<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PendingAmountController extends Controller
{
    //
}
