<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FinalAmountController extends Controller
{
    //
}
