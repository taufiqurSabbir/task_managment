<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="credits">
        Develop by <a href="https://www.facebook.com/taufiqursabbirr/"><strong><span>Taufiqur Sabbir</span></strong></a>
    </div>
</footer><!-- End Footer -->

<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->

<script src="{{asset('dashboard/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('dashboard/assets/vendor/quill/quill.min.js')}}"></script>
<script src="{{asset('dashboard/assets/vendor/simple-datatables/simple-datatables.js')}}"></script>
<script src="{{asset('dashboard/assets/vendor/php-email-form/validate.js')}}"></script>

<!-- Template Main JS File -->
<script src="{{asset('dashboard/assets/js/main.js')}}"></script>

</body>

</html>
